package uk.ac.man.cs.choif.extend.sort;

/**
 * Comparator interface
 * Creation date: (07/29/99 22:22:39)
 * @author: Freddy Choi
 */
public interface Comparator extends sun.misc.Compare {
}
