C99 - An algorithm for domain independent linear text segmentation
Freddy Choi - Jan 2004
http://www.freddychoi.me.uk

This is the Windows version of the C99 algorithm that was presented in my
NAACL00 paper.

[Directories]
bin		contains executables, JAR file and test files
classes		compiled code as individual class files
doc		NAACL'00 paper describing the algorithm
src		source code for C99

[Usage]
"c99 --help"		... for detailed help.
"c99 < 0.raw > 0.hyp"	... to partition the file "0.raw" into topic segments.

[Input]
The input file is a raw text file where each line is a sentence and each token,
or word, is separated by space. (see "0.raw")

[Output]
The same file with topic segment boundaries inserted as ========== (see "0.hyp")

Fred.