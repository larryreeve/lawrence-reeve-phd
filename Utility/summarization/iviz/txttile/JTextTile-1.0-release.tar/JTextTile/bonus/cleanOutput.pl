#! /usr/bin/perl
# Cleans up the output. Removes all commments. Thus, leaving only sentences and boundary markers.

while($line = <STDIN>) {
	if ($line !~ m/^(#|\s*$)/) { print STDOUT $line; }
}
