#! /usr/bin/perl
###################################################################
######################### Resource file 2 #########################
###################################################################
# This Perl script is used to extract the text from a Brown corpus
# file. The result is a list of sentences. The output is readable
# using the class RawText.

$sentence = "";
$separator_stack = 0;
while ($line = <STDIN>) {
	if ($line =~ m/^\*x\*/) {
		while ($line =~ m/^\*x\*/) { $line = <STDIN>; }
		if ($separator_stack > 0) { flush_sentence($sentence); }
		$separator_stack = -1;
	}
	elsif ($line =~ m/^===*/) { $separator_stack++;	}
	elsif ($line !~ m/^\s*$/) {
		if ($separator_stack > 0) {
			flush_sentence($sentence);
			$separator_stack = 0;
		}
		chomp($line);
		$line =~ s/(\[|\])//g;
		$sentence = $sentence . " $line";
	}
}
if ($separator_stack > 0) {
	flush_sentence($sentence);
	$separator_stack = 0;
}

sub flush_sentence {
	($sentence) = @_;
	if ($sentence !~ m/^\s*$/) {
		$sentence =~ s/\s+/ /g;
		$sentence =~ s/(\S+)\/\S+/$1/g;
		$sentence =~ s/^\s*(\S.+\S)\s*$/$1/;
		print STDOUT "$sentence\n";
		$sentence = "";
	}
}
	
