#! /usr/bin/perl
###################################################################
######################### Resource file 1 #########################
###################################################################
# This Perl script is used to simplify a Brown corpus file
# into list of sentences and POS. The output is readable using
# the class Brown.

$sentence = "";
$separator_stack = 0;
while ($line = <STDIN>) {
	if ($line =~ m/^\*x\*/) {
		while ($line =~ m/^\*x\*/) { $line = <STDIN>; }
		if ($separator_stack > 0) { flush_sentence($sentence); }
		$separator_stack = -1;
	}
	elsif ($line =~ m/^===*/) { $separator_stack++;	}
	elsif ($line !~ m/^\s*$/) {
		if ($separator_stack > 0) {
			flush_sentence($sentence);
			$separator_stack = 0;
		}
		chomp($line);
		$line =~ s/(\[|\])//g;
		$sentence = $sentence . " $line";
	}
}
if ($separator_stack > 0) {
	flush_sentence($sentence);
	$separator_stack = 0;
}

sub flush_sentence {
	($sentence) = @_;
	if ($sentence !~ m/^\s*$/) {
		$sentence =~ s/\s+/ /g;
		$sentence =~ s/^\s*(\S.+\S)\s*$/$1/;
		print STDOUT "$sentence\n";
		$sentence = "";
	}
}
	
